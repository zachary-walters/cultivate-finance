<?php
define("DOKU_INC", "/opt/bitnami/dokuwiki/");
