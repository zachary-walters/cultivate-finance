<?php
/**
 * This file configures the default states of available plugins. All settings in
 * the plugins.*.php files will override those here.
 */
$plugins['testing'] = 0;
